package test;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day1 {

	@Test(groups= {"Smoke"})
	public void FirstTest() {
		System.out.println("This is first test case in Day1");
	}

	@Parameters({"myName"})
	@Test(enabled=true)
	public void SecondTest4(String myName) {
		System.out.println("This is Second test4 case in Day1");
		System.out.println(myName);
	}

	
	@Test(dependsOnMethods= {"SecondTest4"})
	public void SecondTest() {
		System.out.println("This is Second test case in Day1");
	}

	@BeforeTest    //it will run before test block in XML
	public void prerequisiteOfTests() {
		System.out.println("We are in Before test");
	}
	
	@AfterTest   //it will run after test block in XML
	public void afterTest() {
		System.out.println("We are in After test");
	}
	
	@BeforeSuite (enabled=false)  //for whole xml
	public void beforeSuite() {
		System.out.println("We are in Before Suite");
	}
	
	@AfterSuite   //for whole xml
	public void bafterSuite() {
		System.out.println("We are in After Suite");
	}
	
	@DataProvider
	public Object getData() {
		Object[][] data = new Object[3][2];
		
		data[0][0]="firstusername";
		data[0][1]="firstpassword";
		
		data[1][0]="secondusername";
		data[1][1]="secondpassword";
		
		data[2][0]="thirdusername";
		data[2][1]="thirdpassword";
		return data;
	}
	
	
	@Test(dataProvider="getData")
	public void testGetData(String userName, String passWord) {
		System.out.println("get data test case........");
		System.out.println(userName);
		System.out.println(passWord);
	}
	
	
	
}
