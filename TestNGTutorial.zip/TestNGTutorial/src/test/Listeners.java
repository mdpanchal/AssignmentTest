package test;

import org.testng.ITestListener;
import org.testng.ITestResult;

//iTestListeners interface which implements tesNG Listeners
public class Listeners implements ITestListener {

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Success Listener");
	}
	
	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failure Listener: "+result.getName());
	}
	
	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("Test Skipped Listener: "+result.getSkipCausedBy());
	}
	
}
