package test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Day3 {
	@Test(groups= {"Smoke"})
	public void FirstTest() {
		System.out.println("This is first test case in Day3");
	}

	@Test
	public void SecondTest() {
		System.out.println("This is Second test case in Day3");
	}

	@Test
	public void ThirdTest() {
		System.out.println("This is third test case in Day3");
	}
	
	
	@BeforeClass    //Scope will be limited to class
	public void beforeClass() {
		System.out.println("before class....");
	}
	
	@AfterClass		//Scope will be limited to class
	public void afterClass() {
		System.out.println("after class....");
	}
	
	
	
	
}
