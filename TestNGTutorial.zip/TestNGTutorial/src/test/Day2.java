package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Day2 {

	@Test(groups= {"Smoke"})
	public void FirstTest() {
		System.out.println("This is first test case in Day2");
	}

	@Test
	public void SecondTest() {
		System.out.println("This is Second test case in Day2");
	}

	@Test
	public void ThirdTest() {
		System.out.println("This is third test case in Day2");
	}

	@BeforeMethod	//scope is only for class
	public void beforeMethod() {
		System.out.println("we are in Before Method, it get executed before each test case/method");
	}
	
	@AfterMethod	//scope is only for class
	public void afterMethod() {
		System.out.println("we are in After Method......");
	}
	
}
