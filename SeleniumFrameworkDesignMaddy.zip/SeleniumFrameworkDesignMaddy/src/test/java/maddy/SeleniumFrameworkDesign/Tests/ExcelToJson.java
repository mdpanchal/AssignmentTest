package maddy.SeleniumFrameworkDesign.Tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.*;
import org.testng.annotations.Test;

public class ExcelToJson {

		FileInputStream fis;
		XSSFWorkbook workbook;
		XSSFSheet sheet ;
		XSSFRow row;
		XSSFCell cell;
		List<String> sheetNames;
		
	
	public void loadExcelData() throws IOException {
		
		//load excel data
				File file = new File("/Users/madhav.panchal/Desktop/ExcelData.xlsx");
				fis = new FileInputStream(file);
				workbook = new XSSFWorkbook(fis);
				loadSheetNames(workbook);
	}
		
		
	public List<String> loadSheetNames(XSSFWorkbook wb) {
		
		//load sheet names
		sheetNames = new ArrayList<String>();
		int noOfSheets= wb.getNumberOfSheets();
		for(int i=0;i<noOfSheets;i++) {
			sheetNames.add(wb.getSheetName(i));
		}
		return sheetNames;
	}
		
		public String getStringValue(XSSFCell cell) {
			String value = cell.getCellType().equals(CellType.STRING)?cell.getStringCellValue()
					
					:cell.getCellType().equals(CellType.NUMERIC)?String.valueOf(cell.getNumericCellValue())
					:cell.getCellType().equals(CellType.BOOLEAN)?String.valueOf(cell.getBooleanCellValue())
					:cell.getCellType().equals(CellType.ERROR)?cell.getErrorCellString()
					:cell.getStringCellValue();						
			
			return value;
		}
		
		
		
		public Map<String, String> getSheetDataFromColumnKeys(XSSFSheet sheet){
			
			Map<String, String> map = new HashMap<String, String>();
			
			for(int i=1;i<sheet.getLastRowNum();i++) {
				row=sheet.getRow(i);
				String keyCell = getStringValue(row.getCell(0));
				
				int columns = row.getLastCellNum();
				
				for (int j = 1;j<columns;j++) {
					String val = getStringValue(row.getCell(j));
					map.put(keyCell, val);
				}
			}
			return map;
		}
		
		
		public List<Map<String, String>> getSheetDataFromRowKeys(XSSFRow keyRow,List<Map<String, String>> rowDataInSheet){
			
			for (int i=1;i<sheet.getLastRowNum();i++) {
				Map<String, String> map = new HashMap<String, String>();
				
				XSSFRow sheetRow = sheet.getRow(i);
				
				for (int s=0;s<keyRow.getPhysicalNumberOfCells();s++) {
					String value  = getStringValue(sheetRow.getCell(s));
					String key  = getStringValue(keyRow.getCell(s));
					map.put(key, value);
				}
				rowDataInSheet.add(map);
			}
			return rowDataInSheet;
		}
		
		
		
		public void createTestDataMapper() throws Exception{
			
			if(sheet==null) {
				loadExcelData();
			}
			Map<String, List<Map<String, String>>> sheetMap = new HashMap<>();
			List<Map<String,String>> testExeMap = new ArrayList<>();
			
			XSSFSheet masterSheet = workbook.getSheet(sheetNames.get(0));
			testExeMap.add( getSheetDataFromColumnKeys(masterSheet));
			
			sheetMap.put(sheetNames.get(0),testExeMap);
			
			
			for(int k = 1;k<sheetNames.size();k++) {
				List<Map<String,String>> rowDataInSheet = new ArrayList<>();
				sheet = workbook.getSheet(sheetNames.get(k));
				XSSFRow keyRow = sheet.getRow(0);
				sheetMap.put(sheet.getSheetName(), getSheetDataFromRowKeys(keyRow, rowDataInSheet));
			}
			System.out.println(sheetMap);
		}
		
		
		public static void main(String[] args) throws Exception {
			ExcelToJson ed = new ExcelToJson();
			ed.createTestDataMapper();
		}
		
		
		
	}


