package maddy.SeleniumFrameworkDesign.Tests;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import maddy.SeleniumFrameworkDesign.TestComponent.BaseTest;
import maddy.SeleniumFrameworkDesign.pageObjects.CheckoutPage;
import maddy.SeleniumFrameworkDesign.pageObjects.ProductCataloguePage;
import maddy.SeleniumFrameworkDesign.TestComponent.Retry;
import maddy.SeleniumFrameworkDesign.pageObjects.CartPage;
import maddy.SeleniumFrameworkDesign.pageObjects.ConfirmationPage;
import maddy.SeleniumFrameworkDesign.pageObjects.OrderPage;

public class ErrorValidationsTest extends BaseTest {

	@Test(groups= {"ErrorHandling"},retryAnalyzer=Retry.class)
	public void LoginErrorValidation() throws IOException, InterruptedException {

	
		landingPage.loginApplication("anshika@gmail.com", "Iamki000");
		AssertJUnit.assertEquals("Incorrect email or password.", landingPage.getErrorMessage());

	}
	

	@Test
	public void ProductErrorValidation() throws IOException, InterruptedException
	{

		String productName = "ZARA COAT 3";
		ProductCataloguePage productCatalogue = landingPage.loginApplication("rahulshetty@gmail.com", "Iamking@000");
		List<WebElement> products = productCatalogue.getProductList();
		productCatalogue.addProductToCart(productName);
		CartPage cartPage = productCatalogue.goToCartPage();
		Boolean match = cartPage.VerifyProductDisplay("ZARA COAT 33");
		Assert.assertFalse(match);
		
	

	}

}
