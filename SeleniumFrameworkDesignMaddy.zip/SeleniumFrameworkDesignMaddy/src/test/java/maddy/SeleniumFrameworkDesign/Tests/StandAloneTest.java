package maddy.SeleniumFrameworkDesign.Tests;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import maddy.SeleniumFrameworkDesign.TestComponent.BaseTest;
import maddy.SeleniumFrameworkDesign.pageObjects.CheckoutPage;
import maddy.SeleniumFrameworkDesign.pageObjects.ProductCataloguePage;
import maddy.SeleniumFrameworkDesign.pageObjects.CartPage;
import maddy.SeleniumFrameworkDesign.pageObjects.ConfirmationPage;
import maddy.SeleniumFrameworkDesign.pageObjects.OrderPage;

public class StandAloneTest extends BaseTest {
	String productName = "ZARA COAT 3";

	@Test(dataProvider= "getData", groups= {"Purchase"})
	public void submitOrder(HashMap<String, String> input) throws InterruptedException {

		ProductCataloguePage productCatalogue = landingPage.loginApplication(input.get("email"), input.get("password"));
		List<WebElement> products = productCatalogue.getProductList();
		productCatalogue.addProductToCart(input.get("productName"));
		CartPage cartPage = productCatalogue.goToCartPage();

		Boolean match = cartPage.VerifyProductDisplay(input.get("productName"));
		Assert.assertTrue(match);
		CheckoutPage checkoutPage = cartPage.goToCheckout();
		checkoutPage.selectCountry("india");
		ConfirmationPage confirmationPage = checkoutPage.submitOrder();
		String confirmMessage = confirmationPage.getConfirmationMessage();
		AssertJUnit.assertTrue(confirmMessage.equalsIgnoreCase("THANKYOU FOR THE ORDER."));

	}

	@Test(dependsOnMethods = { "submitOrder" })
	public void OrderHistoryTest() {
		// "ZARA COAT 3";
		ProductCataloguePage productCatalogue = landingPage.loginApplication("anshika@gmail.com", "Iamking@000");
		OrderPage ordersPage = productCatalogue.goToOrdersPage();
		Assert.assertTrue(ordersPage.VerifyOrderDisplay(productName));

	}

	// Data Provider
	@DataProvider
	public Object[][] getData() throws IOException{
		
//		HashMap<String,String> map = new HashMap<String, String>();
//		map.put("email", "mdpanchal9123@gmail.com");
//		map.put("password", "Maddy@lattitude5510");
//		map.put("product", "ZARA COAT 3");
		
		//alternative
		List<HashMap<String,String>> data =getJaonDataToMap(System.getProperty("user.dir")
				+ "/src/test/java/maddy/SeleniumFrameworkDesignMaddy/data/PurchaseOrder.json");
		return new Object[][] {{data.get(0)}};
	}
	
	
	
	

}
