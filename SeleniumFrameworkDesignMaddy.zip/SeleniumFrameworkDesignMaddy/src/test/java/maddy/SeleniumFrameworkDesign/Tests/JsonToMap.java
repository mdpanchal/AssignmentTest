package maddy.SeleniumFrameworkDesign.Tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class JsonToMap {
	
	@Test
	public void convertJsonToMap() throws JsonMappingException, JsonProcessingException {
		String jsonStr = "[{\n"
				+ "        \"asOfDate\": \"20221022\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"26140191\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"8066.08000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"0.80660763\",\n"
				+ "        \"qty\": \"10000.00000000\",\n"
				+ "        \"wealthSecurityId\": \"c7f7b401-aecb-4aa2-b00e-260300d98537\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221022\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"26140191\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"128220.10000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"128.22000000\",\n"
				+ "        \"qty\": \"1000.00000000\",\n"
				+ "        \"wealthSecurityId\": \"d2b1aff8-87b8-446c-aeb6-c8744caa9d08\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221022\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"26140191\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"19674.46000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"196.74464020\",\n"
				+ "        \"qty\": \"100.00000000\",\n"
				+ "        \"wealthSecurityId\": \"5dda5fdc-116f-4aee-b548-d1b1f6902be1\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221022\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"28942630\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"8285.78000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"8.28570000\",\n"
				+ "        \"qty\": \"1000.00000000\",\n"
				+ "        \"wealthSecurityId\": \"615a6a04-d6be-4dc7-8f07-b0ab0cd8a0f3\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221022\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"28942630\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"10001.30000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"1.00010000\",\n"
				+ "        \"qty\": \"10000.00000000\",\n"
				+ "        \"wealthSecurityId\": \"36dbefff-5a89-4ea2-bfe2-61742e2fc45f\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221025\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"28942630\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"-1007438.98000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"1.00000000\",\n"
				+ "        \"qty\": \"-1007438.97900000\",\n"
				+ "        \"wealthSecurityId\": \"93a9d816-bfe0-4dcd-9fa9-044a0fe371d0\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221024\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"30987590\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"24636.09000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"24.63609000\",\n"
				+ "        \"qty\": \"3.00000000\",\n"
				+ "        \"wealthSecurityId\": \"aaad74da-62b3-45b5-b4b5-357f85d22c30\"\n"
				+ "    },\n"
				+ "    {\n"
				+ "        \"asOfDate\": \"20221023\",\n"
				+ "        \"commission\": \"0.00\",\n"
				+ "        \"currency\": \"USD\",\n"
				+ "        \"custodianAccountNumber\": \"30987590\",\n"
				+ "        \"custodianId\": \"0168\",\n"
				+ "        \"dividendIncome\": \"0.00\",\n"
				+ "        \"inFlow\": \"0.0000\",\n"
				+ "        \"longFlag\": \"1\",\n"
				+ "        \"managementFees\": \"0.00\",\n"
				+ "        \"marketValue\": \"687600.80000000\",\n"
				+ "        \"outFlow\": \"0.0000\",\n"
				+ "        \"price\": \"687.60000000\",\n"
				+ "        \"qty\": \"1000.00000000\",\n"
				+ "        \"wealthSecurityId\": \"59694bc3-6507-4fa3-8707-01fde575f364\"\n"
				+ "    }]\n"
				+ "";

		ObjectMapper mapper = new ObjectMapper();
		//java.util.Map<String, String> map = mapper.readValue(json_string, java.util.Map.class);
		List<Map<String, Object>> listOfMaps = mapper.readValue(jsonStr, new TypeReference< List<Map<String, Object>>>() {});

		System.out.println(listOfMaps);

		
		
		///filter on date
		List<Map<String, Object>> filteredOnDate = listOfMaps.stream().filter(s -> s.get("asOfDate")
			    .equals("20221022")).collect(Collectors.toList());
		System.out.println(filteredOnDate);
		
		
		
		Map<String, Object> mapexpected = new HashMap<String, Object>();
		for (int i=0;i<filteredOnDate.size();i++) {
			
			Map<String, Object> map = filteredOnDate.get(i);
			if(map.get("Ticker").equals("")) {
				mapexpected=map;
			}
		}
		
		
		
		//		Map<String, Object> mapping = new ObjectMapper().readValue(jsonStr, HashMap.class);
//		
//		System.out.println(mapping);
	}
	
//	
//	public static Map<String, Object> jsonToMap(JSONObject json) throws JSONException {
//	    Map<String, Object> retMap = new HashMap<String, Object>();
//	    
//	    if(json != JSONObject.NULL) {
//	        retMap = toMap(json);
//	    }
//	    return retMap;
//	}
//
//	public static Map<String, Object> toMap(JSONObject object) throws JSONException {
//	    Map<String, Object> map = new HashMap<String, Object>();
//
//	    Iterator<String> keysItr = object.keys();
//	    while(keysItr.hasNext()) {
//	        String key = keysItr.next();
//	        Object value = object.get(key);
//	        
//	        if(value instanceof JSONArray) {
//	            value = toList((JSONArray) value);
//	        }
//	        
//	        else if(value instanceof JSONObject) {
//	            value = toMap((JSONObject) value);
//	        }
//	        map.put(key, value);
//	    }
//	    return map;
//	}
//
//	public static List<Object> toList(JSONArray array) throws JSONException {
//	    List<Object> list = new ArrayList<Object>();
//	    for(int i = 0; i < array.length(); i++) {
//	        Object value = array.get(i);
//	        if(value instanceof JSONArray) {
//	            value = toList((JSONArray) value);
//	        }
//
//	        else if(value instanceof JSONObject) {
//	            value = toMap((JSONObject) value);
//	        }
//	        list.add(value);
//	    }
//	    return list;
//	}
//	

}
