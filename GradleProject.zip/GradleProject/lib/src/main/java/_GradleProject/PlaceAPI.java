package _GradleProject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import co.source.Payload;

public class PlaceAPI {

	Payload pLoad = new Payload();

	public void addPlaceAPICall() {
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		given().queryParam("key", "qaclick123").header("Content-Type", "application.json").body(pLoad.addPlacePayload())
				.with().contentType(ContentType.JSON).when().post("maps/api/place/add/json").then().log().all()
				.statusCode(200);
	}

	public void updatePlaceAPICall() {
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		String responseJson = given().queryParam("key", "qaclick123").header("Content-Type", "application.json")
				.body(pLoad.addPlacePayload()).with().contentType(ContentType.JSON).when()
				.post("maps/api/place/add/json").then().extract().response().asString();

		System.out.println(responseJson);
		JsonPath js = new JsonPath(responseJson);

		String placeId = js.getString("place_id");

		System.out.println(placeId);

		String responseAfterUpdate = given().queryParam("key", "qaclick123").header("Content-Type", "application.json")
				.body("{\r\n\"place-id\":\"66462ef6dbe1f0210c64c996b1er45d5\",\r\n "
						+ "\"address\":\"70 Summer walk, USA\",\r\n" + "\"key\":\"qaclick123\"\r\n}")
				.with().contentType(ContentType.JSON).when().put("maps/api/place/add/json").then().extract().response()
				.asString();

		JsonPath js1 = new JsonPath(responseAfterUpdate);

		String placeId1 = js1.getString("place_id");

		System.out.println(placeId1);

	}

	public void getPlaceAPICall() {

		RestAssured.baseURI = "https://rahulshettyacademy.com";

		String responseGetCall = given().queryParam("key", "qaclick123").queryParam("place-id", "c8ca4f86d5b38db0c8559e438a61e5a7").when()
				.get("maps/api/place/add/json").then().extract().response().asString();
		
		
		System.out.println(responseGetCall);

	}

}
