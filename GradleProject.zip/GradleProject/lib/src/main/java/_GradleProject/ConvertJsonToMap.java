package _GradleProject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ConvertJsonToMap {

	public void converJsonToMap() throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		// java.util.Map<String, String> map = mapper.readValue(json_string,
		// java.util.Map.class);

		File input = new File("/Users/madhav.panchal/Downloads/JsonOutputdata.json");
		File ExpectedInput = new File("/Users/madhav.panchal/Downloads/Sample JSON File.json");

		List<Map<String, Object>> listOfMaps = mapper.readValue(input, new TypeReference<List<Map<String, Object>>>() {
		});

		// System.out.println(listOfMaps);

		//code to manage more than one date
		Set<String> uniqueDates = new HashSet<String>();
		
		
		for(Map<String, Object> li: listOfMaps) {
			
			uniqueDates.add((String) listOfMaps.get(0).get("PositionDate"));
		}
		
				
		/// filter on date
		List<Map<String, Object>> filteredOnDate = listOfMaps.stream()
				.filter(s -> s.get("PositionDate").equals("10/22/2022 12:00:00 AM")).collect(Collectors.toList());
		// System.out.println(filteredOnDate);

		Map<String, Map<String, Object>> SecurityIdMap = new TreeMap<>();

		for (int i = 0; i < filteredOnDate.size(); i++) {

			Map<String, Object> map = new HashMap<String, Object>();
			map = filteredOnDate.get(i);
			SecurityIdMap.put((String) map.get("SecurityId"), map);
		}

		List<Map<String, Object>> ExpectedlistOfMaps = mapper.readValue(ExpectedInput,
				new TypeReference<List<Map<String, Object>>>() {
				});

		// System.out.println(ExpectedlistOfMaps);

		/// filter on date
		List<Map<String, Object>> ExpectedfilteredOnDate = ExpectedlistOfMaps.stream()
				.filter(s -> s.get("asOfDate").equals("20221022")).collect(Collectors.toList());
		System.out.println(ExpectedfilteredOnDate);

		Map<String, Map<String, Object>> ExpectedSecurityIdMap = new TreeMap<>();

		for (int i = 0; i < ExpectedfilteredOnDate.size(); i++) {

			Map<String, Object> map = new HashMap<String, Object>();
			map = ExpectedfilteredOnDate.get(i);
			ExpectedSecurityIdMap.put((String) map.get("wealthSecurityId"), map);
		}

		String[] arrWealthSecurityId = { "93a9d816-bfe0-4dcd-9fa9-044a0fe371d0", "aaad74da-62b3-45b5-b4b5-357f85d22c30",
				"59694bc3-6507-4fa3-8707-01fde575f364", "36dbefff-5a89-4ea2-bfe2-61742e2fc45f",
				"615a6a04-d6be-4dc7-8f07-b0ab0cd8a0f3", "5dda5fdc-116f-4aee-b548-d1b1f6902be1",
				"d2b1aff8-87b8-446c-aeb6-c8744caa9d08", "c7f7b401-aecb-4aa2-b00e-260300d98537" };

		String[] arrSecurityId = { "11111111-1111-1111-1111-111111111111", "VAUSA08BXC;VA", "0P0001NKQ9;ST",
				"FMUSA000F6;FM", "F00001AEX6;FI", "F0000169K1;FC", "F000010G53;FO", "F00001092A;FE" };

		Map<String, Object> replaceWealthSecuIdToSecurityIdMap = new TreeMap<String, Object>();

		for (int i = 0; i < ExpectedfilteredOnDate.size(); i++) {

			Map<String, Object> map = new HashMap<String, Object>();
			map = ExpectedfilteredOnDate.get(i);
			for (int j = 0; j < arrWealthSecurityId.length; j++) {

				if (map.get("wealthSecurityId").equals(arrWealthSecurityId[j])) {
					map.remove("wealthSecurityId");
					map.put("SecurityId", arrSecurityId[j]);
					break;
				}
			}
			replaceWealthSecuIdToSecurityIdMap.put((String) map.get("SecurityId"), map);
		}

//		System.out.println(SecurityIdMap);
//		System.out.println(ExpectedSecurityIdMap);
//		System.out.println(replaceWealthSecuIdToSecurityIdMap);

		List<String> keyList = new ArrayList<>();
		for (Map.Entry<String, Map<String, Object>> entry : SecurityIdMap.entrySet()) {

			String keyOfMap = entry.getKey();
			keyList.add(keyOfMap);

//			for (Map.Entry<String, Object> innerEntry : ((Map<String, Object>) entry).entrySet()) {
//		        
//				for (Object o : innerEntry) {
//		            
//		        }
//		    }

		}

		for (int i = 0; i < SecurityIdMap.size(); i++) {

			Map<String, Object> map1 = new HashMap<String, Object>();
			Map<String, Object> map2 = new HashMap<String, Object>();

			map1 = SecurityIdMap.get(keyList.get(i));
			map2 = (Map<String, Object>) replaceWealthSecuIdToSecurityIdMap.get(keyList.get(i));

			String a = map1.get("Price").toString();
			String b = map2.get("price").toString();
			if (b.contains(a)) {
				System.out.println("price Passsed");
			} else {
				System.out.println("failed for " + keyList.get(i) + a + " :" + b);
			}

			a = map1.get("Quantity").toString();
			b = map2.get("qty").toString();
			if (b.contains(a)) {
				System.out.println("Quanity Passsed");
			} else {
				System.out.println("failed for " + keyList.get(i) + a + " :" + b);
			}

			a = map1.get("MVCurrency").toString();
			b = map2.get("currency").toString();
			if (b.contains(a)) {
				System.out.println("currency Passsed");
			} else {
				System.out.println("failed for " + keyList.get(i) + a + " :" + b);
			}
			System.out.println();
			System.out.println();
			System.out.println("#################################################");
			System.out.println();
			System.out.println();
		}

	}

}
