package _GradleProject;

import java.io.IOException;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

public class Test1 {
	
	
	ConvertCSVtoJson conC2J =  new ConvertCSVtoJson();
	ConvertJsonToMap conJ2M =  new ConvertJsonToMap();
	PlaceAPI placeAPI = new PlaceAPI();
	
	@Disabled
	@Test
	@Order(1)
	public void testCSVtoJason() throws IOException {
		
		conC2J.convertCSVtoJson();
		
	}
	

	@Test
	public void testJasontoMap() throws IOException {
		
		
		conJ2M.converJsonToMap();
	}
	
	@Disabled
	@Test 
	public void testAddPlaceAPI() {
		
		placeAPI.addPlaceAPICall();
	}
	
	@Disabled
	@Test
	public void testUpdatePlaceAPI() {
		
		placeAPI.updatePlaceAPICall();
		
	}
	
	@Disabled
	@Test 
	public void testGetPlaceAPI() {
		
		placeAPI.getPlaceAPICall();
	}
	

}
