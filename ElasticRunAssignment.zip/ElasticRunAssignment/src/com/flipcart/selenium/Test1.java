package com.flipcart.selenium;

public class Test1 {

	public static void main(String[] args) {
		
String Category ="Mad'hav";


String s = "//div[@id=\""+Category+"-header\"]";

System.out.println(s);

	}

}
